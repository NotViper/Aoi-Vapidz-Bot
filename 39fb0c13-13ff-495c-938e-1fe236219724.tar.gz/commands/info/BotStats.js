module.exports = {
    name: "botinfo",
    aliases: ["stats","bi"],
    alia: ["stats", "bi"],
    description:"shows the bot's statistics.",
    usage:"no usage given.",
    code: `
$addField[1;Node Versions;\`\`\`js
Node.js    :: $nodeVersion
\`\`\`]
$addField[1;Bot CPU;\`\`\`js
Model CPU :: $djsEval[require ('os').cpus()[0].model;yes]
CPU Usage :: $cpu
OS Platform :: $djsEval[require ('os').platform();yes]
\`\`\`]
$addField[1;Usage;\`\`\`js
RAM Left :: $cropText[$divide[$sub[$maxRam;$ram];1024];4]GB
RAM :: $cropText[$divide[$ram;1024];4]GB
Memory :: $djsEval[process.memoryUsage().rss / 1024 / 1024;yes] MB
\`\`\`]
$addField[1;Main Statistics;\`\`\`js
Commands  :: $commandsCount
Channels  :: $allChannelsCount
Servers   :: $serverCount
Users     :: $numberSeparator[$allMembersCount]
Variables :: $variablesCount
\`\`\`]
$addField[1;Developer;\`\`\`js
NotViper.#9420
\`\`\`]
$footer[1;© Vapidz Development]
$addTimestamp[1]
$color[1;0012ff]
$title[1;Bot Stats | $userTag[$clientId]]
$thumbnail[1;$userAvatar[$clientID]]

$onlyIf[$getGlobalUserVar[blacklist]==false;{newEmbed: {color:000000} {title:**Blacklist**} {description:<:Wrong:932857433225822248> | **Wait Your Blacklist Expired, Appeal At [Vapidz Development](https://discord.gg/J7rKrBhMNT)**}{thumbnail:$authorAvatar}{footer:Blacklisted}}]  
`
}
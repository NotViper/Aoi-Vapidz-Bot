module.exports = ({
  name: 'setprefix',
  aliases: 'prefix',
  usage: 'Setprefix <new prefix>',
  description: 'Sets a new prefix for bot',
  cooldown: '4s',
  code: `$author[1;Prefix Updated;$userAvatar[$clientID]]
$thumbnail[1;$serverIcon[$guildID]]
$description[1;**New Prefix For This server is** \`$message[1]\`]
$color[1;0012ff]
$setServerVar[prefix;$message[1]]

$onlyIf[$charCount[$message[1]]<6;{newEmbed:{description:<:Wrong:932857433225822248> | **Prefix can't be more than 5 characters!**}{color:0012ff}}]
$footer[1;$username[$authorID];$authorAvatar]
$addTimestamp[1]

$onlyIf[$message[1]!=;{newEmbed:{description:<:Wrong:932857433225822248> | **Masukan** \`prefix\` **Untuk Menggantikannya**}{color:0012ff}}]

$onlyIf[$message[1]!=$toLowercase[$getServerVar[prefix]];{newEmbed:{description:<:Wrong:932857433225822248> | \`$getServerVar[prefix]\` **Already Set on This Server**}{color:0012ff}}]

$onlyPerms[manageserver;{newEmbed:{description:<:Wrong:932857433225822248> | **You Needs This Perms —** \`Manage Server\`!}{color:0012ff}}]

$cooldown[$commandInfo[setprefix;cooldown];{newEmbed:{description:<:Wrong:932857433225822248> | **Wait** \`%time%\` **To Update New Prefix On This Server**}{color:0012ff}}]

$onlyIf[$getGlobalUserVar[blacklist]==false;{newEmbed: {color:000000} {title:**Blacklist**} {description:<:Wrong:932857433225822248> | **Wait Your Blacklist Expired, If You Want Appeal Go To [Vapidz Development](https://discord.gg/J7rKrBhMNT)**}{thumbnail:$authorAvatar}{footer:Blacklisted Dari Bot}}]`
});
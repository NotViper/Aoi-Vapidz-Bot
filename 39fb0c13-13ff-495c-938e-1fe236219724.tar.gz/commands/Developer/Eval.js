module.exports = {
  name: "eval",
  aliases: "evaluate",
  code:`
$description[1;
📥 | **Input**
\`\`\`js
$message
\`\`\`
📤 | **Output**
\`\`\`js
$eval[$message;yes;no;no;no]
\`\`\`]
$color[1;0012ff]$footer[1;$charCount[$message] chars | $charCount[$findNumbers[$message]] numbers | $charCount[$findSpecialChars[$message]] special chars]
$onlyIf[$message>=1;<:Wrong:932857433225822248> | **Apa Yang Kamu Mau Eval?**]
$onlyforids[$botownerid;<:Wrong:932857433225822248> | **hanya developer dapat menggunakan command ini!**]
$reply
`
}  
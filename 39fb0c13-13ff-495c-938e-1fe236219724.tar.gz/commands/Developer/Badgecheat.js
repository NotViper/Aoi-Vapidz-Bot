module.exports = {
name: "badgeset",
aliases: "badgecheat",
$if: "v4",
code: `
$if[$message[2]==bughunter]
$title[1;**Cheat Actived**]
$color[1;$getVar[embedcolor]]

$description[1;**Berhasil Cheat Badge Bug Hunter Ke** $username[$get[u]]]

$setGlobalUserVar[bughunterbadge;$message[1];$get[u]]

$let[u;$findUser[$message[3];yes]]

$onlyIf[$message[1]>1;<:Wrong:932857433225822248> | **$getServerVar[prefix]badgecheat < True/False > < Badge > < User >**]

$onlyForIds[$botownerid;]
$endif

$if[$message[2]==orangkayakaya]
$title[1;**Cheat Actived**]

$color[1;$getVar[embedcolor]]

$description[1;**Berhasil Cheat Badge Bug Hunter Ke** $username[$get[u]]]

$setGlobalUserVar[richbadge;$message[1];$get[u]]

$let[u;$findUser[$message[3];yes]]

$onlyIf[$message[1]>1;<:Wrong:932857433225822248> | **$getServerVar[prefix]badgecheat < True/False > < Badge > < User >**]

$onlyForIds[$botownerid;]
$endif
`}
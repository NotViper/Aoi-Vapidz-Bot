module.exports = {
 name: "nekolewd",
 code: `
 $description[1;FBI Open Up The Door]
 $image[1;$httpRequest[https://neko-love.xyz/api/v1/nekolewd;GET;;url]]
$color[1;RANDOM]
 $onlyNsfw[Only nsfw channel]`}
module.exports = {
 name: "whitelist",
 code: `
$color[1;0012ff]
$thumbnail[1;$userAvatar[$findUser[$message]]]
$setGlobalUserVar[Blacklist;false;$findUser[$message[1]]]
$description[1;<:Whitelist:907914771993620501> | **$username[$findUser[$message[1]]]#$discriminator[$findUser[$message[1]]] pengguna itu telah di whitelist, dan dia bisa bermain bot ini lagi!**]
$onlyIf[$findUser[$message[1]]!=$authorID;<:Wrong:932857433225822248> | **Anda tidak dapat whitelist diri sendiri**]
$onlyForIDs[$botownerid;<:Wrong:932857433225822248> | **Anda bukan developer saya!**]`
}
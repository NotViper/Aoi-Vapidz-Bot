module.exports = {
name: "set",
aliases: "cheat",
$if: "v4",
code: `
$title[1;**Cheat Actived**]
$color[1;$getVar[embedcolor]]
$description[1;**Saya Telah Cheat Uang $username[$get[u]]'s Ke Rp.**\`$numberSeparator[$message[1];,]\` <:Rupiah:902887569975541810>]
$setGlobalUserVar[Uang;$sum[$getGlobalUserVar[Uang];$message[1]];$get[u]]
$let[u;$findUser[$message[2];yes]]
$onlyIf[$isNumber[$message[1]]==true;<:Wrong:932857433225822248> | **$getServerVar[prefix]cheat < Jumlah > @user**]
$onlyForIds[$botownerid;]
`
}
module.exports = [{
name: "blacklist",
$if: "v4",
code: `
$color[1;RED]
$description[1;**Menambahkan $usertag[$get[u]] Ke List Blacklist!**]
$setGlobalUserVar[blacklist;true;$get[u]]
$onlyIf[$get[u]!=$authorid;<:Wrong:932857433225822248> | **Tentukan ID Pengguna**]
$let[u;$findUser[$message;yes]]
$onlyforids[$botownerid;]`
} , {
name: "unblacklist",
code: `
$color[1;RED]
$description[1;**Menghapuskan $usertag[$get[u]] Dari List Blacklist!**]
$setGlobalUserVar[blacklist;false;$get[u]]
$onlyIf[$get[u]!=$authorid;<:Wrong:932857433225822248> | **Tentukan ID Pengguna**]
$let[u;$findUser[$message;yes]]
$onlyforids[$botownerid;]`}]
module.exports = {
name: "refreshcrypto",
code: `
$setGlobalUserVar[hargajualvapidzcryptocoin;$random[100000;200000]]
$setGlobalUserVar[hargajualbitcoin;$random[50000;150000]]
$title[1;Crypto RPG Telah DiRefresh!]
$thumbnail[1;$authorAvatar]
$color[1;0012ff]
$description[1;
• **Vapidz Crypto Coin**: \`$numberSeparator[$random[100000;200000];,]\`
• **Bitcoin**: \`$numberSeparator[$random[50000;150000];,]\`]
$addTimestamp[1;$dateStamp]
$footer[1;© Vapidz Studios]

$onlyForIDs[$botownerid;]`}
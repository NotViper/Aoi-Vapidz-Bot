module.exports = {
name:"reload",
aliases: "update",
code:`
$title[1;<:Correct:932857414645063701> | Reload Berhasil!]
$description[1;
**Jumlah Commands Baru:** $get[new] Command(s)\n
**Reloaded:** $commandsCount Command(s)
**Ping :** \`$numberSeparator[$ping] ms\`
]
$footer[1;$serverName;$serverIcon]
$thumbnail[1;$userAvatar[$clientID]]
$color[1;0012ff]
$addTimeStamp[1]
$channelSendMessage[$channelID;<:reload:932902378812874752> | **Reloading Commands...**{delete:0.6s}]
$let[new;$math[$get[after]-$get[before]]]
$let[after;$commandsCount]
$updateCommands
$let[before;$commandsCount]
$onlyForIDs[$botownerid;<:Wrong:932857433225822248> | **Hanya Developer Bisa Menggunakan Command ini!**]
`
} 
module.exports = {
 name: "deval",
 aliases: ['djs', 'djseval'],
 help: {
 description: "Evaluate some javascript code!",
 usage: "deval <code>",
 perms: "BOT_OWNER"
 },
 code: `
\`\`\`js
$djsEval[try {
 $message
} catch (err) {
 err
};yes]
\`\`\`
 $argsCheck[>0;{newEmbed:{description:<:Wrong:932857433225822248> | **Penggunaan Commands: ** \`$getServerVar[prefix]$commandInfo[$toLowercase[$commandName];help.usage]\`}{color:0012ff}}]
 $onlyForIDs[$botOwnerID;{newEmbed:{description:<:Wrong:932857433225822248> | **Permission diperlukan: ** \`$commandInfo[$toLowercase[$commandName];help.perms]\`}{color:0012ff}}]
 `
} 
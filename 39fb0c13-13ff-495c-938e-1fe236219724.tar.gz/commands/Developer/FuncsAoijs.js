module.exports = {
name: "func",
aliases: ['funcs','commands','code','function'],
code: `
$title[1;$getObjectProperty[data[0].name];https://github.com/Leref/aoi.js/tree/master/package/functions/funcs/$replaceText[$getObjectProperty[data[0].name];$;usd]]
$author[1;aoi.js (Stable)]
$addField[1;Sumber;[Documentation](https://github.com/Leref/aoi.js/tree/master/package/functions/funcs/;yes]
$addField[1;Depkripsi;\`\`\`$getObjectProperty[data[0].desc]\`\`\`]

$addField[1;Penggunaan;\`\`\`php
$getObjectProperty[data[0].usage]\`\`\`]
$addTimestamp[1]
$color[1;0012ff]
$createObject[$jsonRequest[https://github.com/Leref/aoi.js/tree/master/package/functions/funcs/$message]]
$argsCheck[>0;<:Wrong:932857433225822248> | **Silakan masukkan nama functions.**]
$suppressErrors[<:Wrong:932857433225822248> | **Functions** \`$message\` **tidak ditemukan atau ada yang tidak beres.**]

$thumbnail[1;https://media.discordapp.net/attachments/905683001151737856/929669996542570536/1ee69ccb01e4a8738bada12cd7e631dc.webp]`
}
module.exports = {
 name: "filter-subboost",
 type: "awaited",
 code: `$setServerVar[filters;Subboost]
$let[filter;$setFilter[{"asubboost": "0.75"}]]
$interactionReply[<:Correct:932857414645063701> **| Success Applyed Filter** \`subboost\`.;;;;;yes]`
}
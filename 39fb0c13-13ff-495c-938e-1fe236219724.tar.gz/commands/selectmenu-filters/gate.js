module.exports = {
 name: "filter-gate",
 type: "awaited",
 code: `$setServerVar[filters;Gate]
$let[filter;$setFilter[{"agate": "1"}]]
$interactionReply[<:Correct:932857414645063701> **| Success Applyed Filter** \`gate\`.;;;;;yes]`
}
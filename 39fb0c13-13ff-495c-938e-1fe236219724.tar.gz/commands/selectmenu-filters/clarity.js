module.exports = {
 name: "filter-clarity",
 type: "awaited",
 code: `$setServerVar[filters;Clarity]
$let[filter;$setFilter[{"aecho": "1.0:0.7:0.1:0.7"}]]
$interactionReply[<:Correct:932857414645063701> **| Success Applyed Filter** \`clarity\`.;;;;;yes]`
}
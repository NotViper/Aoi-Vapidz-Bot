module.exports = {
 name: "filter-vibrato",
 type: "awaited",
 code: `$setServerVar[filters;Vibrato]
$let[filter;$setFilter[{"vibrato": "4"}]]
$interactionReply[<:Correct:932857414645063701> **| Success Applyed Filter** \`vibrato\`.;;;;;yes]`
}
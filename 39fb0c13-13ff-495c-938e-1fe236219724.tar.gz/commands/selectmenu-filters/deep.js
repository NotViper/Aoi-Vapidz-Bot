module.exports = {
 name: "filter-deep",
 type: "awaited",
 code: `$setServerVar[filters;Deep]
$let[filter;$setFilter[{"atempo": "1.15", "asetrate": "48000*0.8"}]]
$interactionReply[<:Correct:932857414645063701> **| Success Applyed Filter** \`deep\`.;;;;;yes]`
}
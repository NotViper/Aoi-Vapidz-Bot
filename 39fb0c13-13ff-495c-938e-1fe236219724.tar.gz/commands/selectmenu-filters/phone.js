module.exports = {
 name: "filter-phone",
 type: "awaited",
 code: `$setServerVar[filters;Phone]
$let[filter;$setFilter[{"aresample": "8000"}]]
$interactionReply[<:Correct:932857414645063701> **| Success Applyed Filter** \`phone\`.;;;;;yes]`
}
module.exports = {
 name: "filter-pulsator",
 type: "awaited",
 code: `$setServerVar[filters;Pulsator]
$let[filter;$setFilter[{"apulsator": "1"}]]
$interactionReply[<:Correct:932857414645063701> **| Success Applyed Filter** \`pulsator\`.;;;;;yes]`
}
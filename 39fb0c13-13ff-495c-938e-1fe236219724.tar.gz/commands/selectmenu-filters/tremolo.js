module.exports = {
 name: "filter-tremolo",
 type: "awaited",
 code: `$setServerVar[filters;Tremolo]
$let[filter;$setFilter[{"tremolo": "2"}]]
$interactionReply[<:Correct:932857414645063701> **| Success Applyed Filter** \`tremolo\`.;;;;;yes]`
}
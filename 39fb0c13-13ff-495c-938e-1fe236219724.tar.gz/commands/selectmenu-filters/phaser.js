module.exports = {
 name: "filter-phaser",
 type: "awaited",
 code: `$setServerVar[filters;Phaser]
$let[filter;$setFilter[{"aphaser": "1"}]]
$interactionReply[<:Correct:932857414645063701> **| Success Applyed Filter** \`phaser\`.;;;;;yes]`
}
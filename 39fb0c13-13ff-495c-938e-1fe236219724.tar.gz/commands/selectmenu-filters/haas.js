module.exports = {
 name: "filter-haas",
 type: "awaited",
 code: `$setServerVar[filters;Haas]
$let[filter;$setFilter[{"haas": "1"}]]
$interactionReply[<:Correct:932857414645063701> **| Success Applyed Filter** \`haas\`.;;;;;yes]`
}
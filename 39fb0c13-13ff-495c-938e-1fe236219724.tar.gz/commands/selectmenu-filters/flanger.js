module.exports = {
 name: "filter-flanger",
 type: "awaited",
 code: `$setServerVar[filters;Flanger]
$let[filter;$setFilter[{"flanger": "1"}]]
$interactionReply[<:Correct:932857414645063701> **| Success Applyed Filter** \`flanger\`.;;;;;yes]`
}
module.exports = {
 name: "filter-remove",
 type: "awaited",
 code: `$setServerVar[filters;$getVar[filters]]
$let[filter;$resetFilters]
$interactionReply[<:Correct:932857414645063701> **| Filter Has Been Reseted!**;;;;;yes]`
}
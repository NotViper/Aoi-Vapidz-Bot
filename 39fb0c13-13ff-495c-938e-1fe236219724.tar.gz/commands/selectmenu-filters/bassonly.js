module.exports = {
 name: "filter-bassonly",
 type: "awaited",
 code: `$setServerVar[filters;Bass-only]
$let[filter;$setFilter[{"aresample": "1000"}]]
$interactionReply[<:Correct:932857414645063701> **| Success Applyed Filter** \`bassonly\`.;;;;;yes]`
}
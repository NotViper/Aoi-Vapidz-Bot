module.exports = {
name: "<@$clientid>",
nonPrefixed: true,
code: `
$title[1;**Hello $username!**]
$thumbnail[1;$userAvatar[$clientID]]
$color[1;$getVar[color]]
$description[1;<:question:932874309544837210> | **My Prefix Is $getServerVar[prefix]**

**Commands List :** **type** **[$getServerVar[prefix]help](https://discord.gg/J7rKrBhMNT)** **For My Commands!**
]
$onlyIf[$checkContains[$message;<@$clientid>;<!@$clientid>]==true;]

$addbutton[1;Vapidz Development;5;https://discord.gg/J7rKrBhMNT;no;<:icons_Discord:936923074765422662>]

$addbutton[1;Invite Bot;5;https://discord.com/api/oauth2/authorize?client_id=877382286612504666&scope=bot+applications.commands;no;<:iconInvite:940053861408858123>]`
  }
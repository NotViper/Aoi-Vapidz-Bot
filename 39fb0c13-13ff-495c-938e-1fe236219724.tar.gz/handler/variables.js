module.exports = (bot) => {
    bot.variables({
  //Customize Property For Message
  prefix: "V.",
  blacklist: "false",
  pause: "<:icons_pause:958201165630283786> | Paused.",
  resume: "<:resume:958201523240833035> | Resumed!",
  skip: "⏩ | Skipped!",  //Available {song}
  stop: "⏹ | Stopped.",  
  remove: "<:Correct:932857414645063701> **| Removed song on** {d-amount}.", //Available {d-amount}

  shuffle: "<:Correct:932857414645063701> **| Success Shuffle Queue.**",
  errorjoin: "<:Wrong:932857433225822248> **| Please Join The VC First!**",
  errorqueue: "<:Wrong:932857433225822248> **| There no song was playing.**",
  errorloop: "Only have {amount} song.", //Available {amount}
  erroruser: "{newEmbed:{title:❌ You cant use this command} {color:$getVar[color]}}",
  errorsameuser: "<:Wrong:932857433225822248> **| You must same in** {voice} **to use this command.**", //Available {voice}
  customerror: "Something just happened.", //Custom $suppressErrors

  join: "<:Correct:932857414645063701> **| Joined Voice Channel to the** {join}.", //Available {join}
  dc: "<:Correct:932857414645063701> **| Disconnected.**",
  leftvc: "<:Wrong:932857433225822248> **| There no song again on queue.**", //Description
  secondleftvc: "<:Correct:932857414645063701> **| Left VC.**", //Footer

  //Changing Other
  color: "0012ff",
  channelstatus: "", //Optional (channelid), for send ready message
  vol: "50", //Default Volume
  maxvol: "150", //Max Volume

  //Changing Other - Advance
  permission: "2176183360",
  deafenclient: "1", //Server Deafen Client, 0 = false | 1 = true
  defaultspotify: "youtube", //YouTube/SoundCloud
  multiseek: "1000",
  userid: "default",
  logmusic: "1", //0 = off | 1 = on
  247: "0", //0 = off | 1 = stay 24/7
  last: "null",
  linkdownload: "",
  filters: "none",
  cachemessageid: "",
  cacheplay: "",
  listfilters: "\`bassonly, clarity, echo, flanger, deep, haas, gate, nightcore, phaser, pitch, phone, pulsator, reverb, tempo, tremolo, remove, subboost, vaporwave, vibrato\`",

  //Emoji
  customemoji1: "https://cdn.discordapp.com/emojis/852434440668184615.png?size=4096",
  customemoji2: "https://cdn.discordapp.com/emojis/951749233919279125.png?size=4096",
  ytemoji: "https://cdn.discordapp.com/emojis/852432148207108110.png?size=4096",
  scemoji: "https://cdn.discordapp.com/emojis/852432173758676993.png?size=4096",
  loademoji: "https://cdn.discordapp.com/emojis/951749045787959337.gif?size=4096",
 
  listenuser: "0",
  listenserver: "0",
  listenglobal: "0"
 }, "VapidzAoiJs" )
}
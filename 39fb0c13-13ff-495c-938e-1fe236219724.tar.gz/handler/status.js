module.exports = (bot) => {
    bot.status({
        text: "V.help | V.",
        type: "PLAYING",
        status: "idle",
        time: 12
    })

   bot.status({
     text: "Menjaga $serverCount Dan $allMembersCount Members",
     type: "WATCHING",
     status: "idle",
     time: 12
   })
    
    bot.status({
     text: "Dev Comli🗿🙏",
     type: "WATCHING",
     status: "idle",
     time: 12
   })
}
module.exports = {
    Bot: {
    token: "ODc3MzgyMjg2NjEyNTA0NjY2.YRxz7g.7C3x0D_wmFVfKmVoLxvhfUgKeBA",
    prefix: ["$getServerVar[prefix]","<@$clientID>","<@!$clientID"],
    intents: "all",
    database: {
type:'default',
db:require('dbdjs.db'),
path:"./db/",
        tables:["VapidzAoiJs"],
promisify:false
    },
    respondOnEdit: {
        commands: true
    },
    debug: {
        interpreter : true 
}
}
}